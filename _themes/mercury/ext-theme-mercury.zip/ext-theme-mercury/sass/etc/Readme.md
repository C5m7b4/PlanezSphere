# ext-theme-mercury/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-theme-mercury/sass/etc"`, these files
need to be used explicitly.
